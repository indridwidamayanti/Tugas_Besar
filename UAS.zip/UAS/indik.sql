-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Bulan Mei 2019 pada 14.56
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `NIM` text NOT NULL,
  `TTL` text NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `post`
--

INSERT INTO `post` (`id`, `Nama`, `NIM`, `TTL`, `waktu`) VALUES
(24, 'Gladys Dwi Mawarni', ' 09031281823027', ' Palembang, 2 Agustus 2000', '2019-03-05 16:08:39'),
(26, 'Septiani Aulia Putri', ' 09031281823141', ' Palembang, 28 September 2001', '2019-03-05 16:10:12'),
(31, 'Indri Dwi Damayanti', '09031281823043', '10 September 2000', '2019-05-12 12:40:25'),
(36, 'Mahdihyah Afifah Sari', ' 09031181823001', ' Palembang, 29 Desember 2000', '2019-05-12 12:39:37');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'indricantik', 'indri123'),
(2, 'ndrek', '1945'),
(3, 'ndrekk', '12345'),
(4, 'okeoke', 'ooo'),
(5, 'sep', 'septi'),
(6, 'sepp', 'sepp'),
(7, '', ''),
(8, 'ndrekk', '333'),
(9, 'ooo', 'ooo'),
(10, 'indricantik', 'indri123'),
(11, 'aaaa', 'aaaa'),
(12, 'UHUY', 'UHUY'),
(13, 'UHUY', 'UHUY'),
(14, 'UHUY', 'uhuy'),
(15, '123', '123'),
(16, 'aaaa', 'aaaa'),
(17, 'nab', '123'),
(18, 'pweb2', 'pweb2'),
(19, 'sinusa', 'sinusa'),
(20, 'aa', 'aa'),
(21, 'ihsan', 'ihsan'),
(22, 'aaaa', 'aaaa'),
(23, 'ndrek', 'ndrek');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
